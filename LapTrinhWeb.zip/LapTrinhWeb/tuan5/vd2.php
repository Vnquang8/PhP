<?php 
  $m1 = array();
  $m2 = array('x1'=>1,'x2'=>2);
  $m3 = []; $m4 = ['x1'=> 1 ,'x2'=>2];
  print_r($m1);
  var_dump($m1);
  var_dump($m4);
  $m4['x3']=3;
  echo '<br>';
  unset($m4['x2']);
  var_dump($m4);
  $s=0;
  foreach($m4 as $a => $b)
  {
    $s+=$b;
    echo"<br>$a-$b";
  }
  

  echo "<br>$s<br>";
  foreach($m4 as $v)
  {
    echo "$v";
  }
?>