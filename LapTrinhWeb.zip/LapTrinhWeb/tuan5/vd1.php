 <?php
  $s1 = 'abc';
  $s2 = "abc";
  $s3 = $s1 . $s2;
  $s4 = '$s1 + $s2';
  function f ($x1,&$x2,$x3=3,$x4=4)
  {
    $sum = $x1 + $x2 + $x3 + $x4;
    $x1 = 0 ;$x2 = 0;
    return $sum;
  }
  $a1 = 1 ; $a2=2;
  $a3 = 3 ; $a4 = 4;
  $s1 = F($a1,$a2,$a3,$a4);//10 1 0 3 4
  echo "$s1-$a1-$a2-$a3-$a4";
  $s2 = F($a1,$a4,$a3);//12 1 4 3 4
  echo "<br>$s2-$a1-$a2-$a3-$a4";
  $s3 = F($a1,$a3);//11 1 0 0 0
  echo "<br>$s3-$a1-$a2-$a3-$a4";
?>

