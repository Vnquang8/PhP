<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <?php
  require 'a.php';
  require_once'a.php'; //tao 1 lan duy nhat
  echo $b*a;
  ?>
  <?php ?>
</body>
</html>