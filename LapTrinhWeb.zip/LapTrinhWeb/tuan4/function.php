 <?php 
  // function F($x,&$y,$z=1)
  // {
  //   $x=2;$y=4;$z=5;
  //   return $x+$y+$z;
  // }
  // $a = 1;$b=1;$c=1;
  // $s = f($a,$b,$c);
  // echo "$a - $b - $c - $s";
  // echo"<br/>";
  // $s2 = f($a,$b);
  // echo"$a-$b-$c-$s2";
?> 

<?php 
  function bcc ($n,$c='pink')
  {
    ?>
    <table bgcolor='<?php echo $c ?>' border="1">
      <tr>
        <td colspan=3>Bang Cuu Chuong <?php echo $n ?></td>
        <?php 
        for ($i=1; $i <=10  ; $i++) 
        { ?>
          <tr>
            <td><?php echo $n?></td>
            <td><?php echo $i?></td>
            <td><?php echo $n*$i?></td>
          </tr>
          <?php 
        }
        ?>
      </tr>
    </table>
  <?php
  }
?>

<style>

  .c1{
    float: left;
    width: 20%;
    margin-bottom: 20px;
    border: 1px;
  }
  table{
    border-color: blue;
    color: black;
  }
</style>
<?php 
  for ($i=1; $i <= 10 ; $i++) 
  { ?>
      <div class='c1'>
        <?php echo bcc($i) ?>
      </div>
  <?php 
  }
  ?>

