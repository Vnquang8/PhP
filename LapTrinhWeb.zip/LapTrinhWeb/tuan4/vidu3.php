<?php
$a = [
  'sp1' => 2,
  'sp2' => 4,
  'sp3' => 7
];
foreach ($a as $key => $value) {
  echo "k=$key,v=$value<br>";
}
echo '<hr>';
foreach ($a as $key => $value) {
  echo "<br>v=$value";
}
?>
<table>
  <?php
  $i=0;
  foreach ($variable as $key => $value) {
    # code...
  }

</table>
