<?php
  $a =[
    'x1'=>2,
    'x2'=>4,
    'x3'=>6
  ];
  $x = 'x3';
  $b=$a[$x];echo $b;//6
  $x='x4';$c = isset($a[$x])?$a[$x]:'00';
  echo $c;//error
  unset ($a['x1']);//xoa ptu x1
  var_dump($a);