<?php 
  $a = array(); //mang rong, 0ptu
  $b = array(1,2);//2 ptu
  $c = [];//giong mang a -> mang rong
  $d = [1,3,5];//mang co 3 ptu
  $e = ['sp1'=>'san pham 1','sp2'=>'san pham 2'];

  echo "<pre>";
  var_dump($a);
  print_r($b);
  var_dump($b);
  print_r($d);
  var_dump($e);

  $f =[
    'sp1'=>2,
    'sp2'=>5,
    'sp3'=>1
  ];
  $f['sp4']=8;
  $f['sp1']=10;
  var_dump($f);

  $g = [];
  $g[] = 6;
  $g[] = 9;
  $g[10]= 69;
  var_dump($g);


  $u = 1;
  echo $u; 
?>